# FinScore MEGAMOTOS — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Ajustado | **847.5** (Levemente Abaixo do Risco) |
| Régua Berkley | Muito Abaixo do Risco — aprova (2%) |

Fonte: balancetes anuais 2023–2025. Simulação de teste; Serasa não informado (0).
