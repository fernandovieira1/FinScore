# FinScore MEGAADM — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Ajustado | **157.5** (Levemente Acima do Risco) |
| Régua Berkley | Levemente Acima do Risco — recusar |

Fonte: balancetes anuais 2023–2025. Simulação de teste; Serasa não informado (0).
