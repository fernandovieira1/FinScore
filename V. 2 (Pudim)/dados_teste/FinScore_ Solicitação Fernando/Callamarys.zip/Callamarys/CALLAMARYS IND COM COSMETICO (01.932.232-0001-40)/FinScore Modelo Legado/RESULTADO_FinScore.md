# FinScore CALLAMARYS — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Bruto | **-1.04** (Levemente Acima do Risco) |
| FinScore Ajustado | **240.0** (Levemente Acima do Risco) |
| Régua Berkley | Levemente Acima do Risco — recusar |

Planilha-fonte: 16 campos, triênio 2023–2025 (balancetes anuais), com p_Passivo_Total padronizado = Ativo (convenção do código). Simulação de teste com o modelo atual, rodada em 27/07/2026 para compor esta devolução; Serasa não informado (0).
