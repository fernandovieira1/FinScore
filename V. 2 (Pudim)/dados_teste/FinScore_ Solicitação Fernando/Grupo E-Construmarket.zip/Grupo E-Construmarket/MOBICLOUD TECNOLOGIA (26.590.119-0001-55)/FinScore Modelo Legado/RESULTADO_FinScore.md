# FinScore MOBICLOUD — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Ajustado | **905.0** (Muito Abaixo do Risco) |
| Régua Berkley | Muito Abaixo do Risco — aprova (2%) |

Fonte: BP+DRE gerenciais 2023–2025. Simulação de teste; Serasa não informado (0).
