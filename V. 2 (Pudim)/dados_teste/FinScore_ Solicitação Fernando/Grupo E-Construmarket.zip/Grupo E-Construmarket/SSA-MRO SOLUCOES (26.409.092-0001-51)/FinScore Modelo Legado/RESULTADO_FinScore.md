# FinScore SSAMRO — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Ajustado | **255.0** (Neutro) |
| Régua Berkley | Neutro — recusar salvo aprovação prévia Berkley (3%) |

Fonte: BP+DRE gerenciais 2023–2025. Simulação de teste; Serasa não informado (0).
