# FinScore ECONSTRUMARKET — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Ajustado | **650.0** (Neutro) |
| Régua Berkley | Levemente Abaixo do Risco — aprova (2,5%) |

Fonte: BP+DRE gerenciais 2023–2025. Simulação de teste; Serasa não informado (0).
