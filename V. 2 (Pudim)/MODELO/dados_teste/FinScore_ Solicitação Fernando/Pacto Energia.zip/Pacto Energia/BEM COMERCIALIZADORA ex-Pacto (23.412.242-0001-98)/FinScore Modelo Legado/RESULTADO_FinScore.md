# FinScore PACTO/BEM — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Ajustado | **855.0** (Levemente Abaixo do Risco) |
| Régua Berkley | Muito Abaixo do Risco — aprova (2%) |

Fonte: balancetes anuais consolidados 2024–2025 + DFs assinadas (2023 em R$ mil). Simulação de teste; Serasa não informado (0).
