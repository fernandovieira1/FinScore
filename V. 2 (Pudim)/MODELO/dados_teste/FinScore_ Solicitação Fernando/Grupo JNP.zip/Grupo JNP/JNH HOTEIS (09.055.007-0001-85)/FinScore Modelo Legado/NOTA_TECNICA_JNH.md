# Nota Técnica — FinScore JNH HOTÉIS LTDA (oficial)

**Empresa:** JNH Hotéis Ltda — CNPJ 09.055.007/0001-85 (parte do **Grupo JNP**; JNS Seguradora e JNA Agropecuária pendentes de documentação).
**Período:** 2023–2025 · **Fonte:** Balanço + DRE do **SPED ECD** (livros 14, 15, 16), assinados.
**Modelo:** produção (scikit-learn 1.4.2). **Data:** 01/07/2026.

## Resultado
| Métrica | Valor | Classificação |
|---|---|---|
| FinScore **Bruto** | **1,07** | Levemente Abaixo do Risco (régua do código) |
| FinScore **Ajustado** | **767,5** | **Muito Abaixo do Risco** (régua Berkley: > 750) |

- Régua Berkley (decisória): **> 750 → Muito Abaixo do Risco**, LMI R$ 1.500.000,00, taxa 2%. → **passa no filtro eliminatório do FinScore.**
- Nota: a régua do próprio código (750–875 = "Levemente Abaixo") difere da Berkley; o valor é o mesmo (767,5), muda só o rótulo. Para decisão, vale a Berkley.

## Scores por ano (recente → antigo)
2025 = +2,305 · 2024 = +0,349 · 2023 = −2,655 · pesos 0,60/0,25/0,15 → **Bruto 1,07**. Variância PCA: 59,6% / 40,4%.

## Os 16 campos (R$)
| Campo | 2023 | 2024 | 2025 |
|---|--:|--:|--:|
| Ativo Circulante | 3.710.435,97 | 2.183.317,11 | 1.993.817,47 |
| Ativo Total | 13.791.338,77 | 13.489.651,64 | 17.065.301,62 |
| Caixa (Disponível) | 1.752.594,33 | 567.760,44 | 125.482,69 |
| Estoques | 255.303,25 | 301.136,68 | 355.351,91 |
| Contas a Pagar (Fornecedores) | 367.217,43 | 321.936,68 | 273.543,12 |
| Contas a Receber (cartões + a receber) | 1.503.095,21 | 1.215.798,96 | 1.440.858,18 |
| Passivo Circulante | 3.215.527,51 | 3.737.775,16 | 4.415.401,81 |
| Passivo Total (= Ativo) | 13.791.338,77 | 13.489.651,64 | 17.065.301,62 |
| Patrimônio Líquido | 3.825.000,00 | 3.863.636,36 | 3.863.636,36 |
| Amortização | 0 | 0 | 0 |
| Custos | 9.673.045,66 | 10.190.324,78 | 11.535.358,04 |
| Depreciação | 1.042.288,56 | 1.042.288,56 | 1.744.105,86 |
| Despesa de Impostos (IRPJ+CSLL) | **−71.086,07** | 200.654,28 | 1.052.852,66 |
| Despesa de Juros (desp. financeiras) | 919.840,11 | 844.553,58 | 765.526,90 |
| Lucro Líquido | 3.708.687,99 | 4.403.642,27 | 2.240.353,93 |
| Receita Total (líquida) | 15.638.617,71 | 17.086.510,68 | 18.678.792,30 |

## Premissas e conferências
- **Equação patrimonial fecha** nos 3 anos (Ativo = Exigível + PL, dif. R$ 0,00). Lucro do período reconciliado com a DRE.
- **Sinais:** despesas (Custos, Depreciação, Juros, Impostos) em módulo positivo (a fórmula aplica o negativo: `EBIT = Lucro + Juros + Impostos`).
- **IRPJ/CSLL 2023 = −71.086,07 (crédito, não despesa):** a DRE de 2023 traz imposto sobre o lucro **positivo** (benefício fiscal). Lançado com sinal negativo para o EBIT ficar correto — é exceção legítima à regra "em módulo".
- **PL = capital social:** o lucro é distribuído a cada ano (conta "Lucros a Pagar" no passivo); o balanço fecha com PL = capital, então **não** se soma o resultado ao PL (diferente da Super G).
- **Caixa (p_Caixa) = Disponível** (caixa + bancos + aplicações). Aplicações pequenas e de movimento; sem parcela vinculada relevante.
- **Amortização = 0:** a DRE só destaca Depreciação (amortização de intangível ~R$ 4 mil/ano, imaterial).

## Leitura de crédito e ressalvas
- Empresa **lucrativa e crescente em receita** (15,6 → 17,1 → 18,7 mi). **Margem líquida caiu em 2025** (12,0% vs 23–26% antes) por maior depreciação (1,74 mi), maior IRPJ/CSLL (1,05 mi) e "Outras Despesas Administrativas" (1,84 mi) — investigar no módulo complementar.
- **Endividamento** concentrado em **passivo de arrendamento** (leasing) — 2,2 mi circulante + 8,8 mi não circulante em 2025.
- **Fragilidade de n=3:** como todo FinScore, o resultado é relativo à trajetória de 3 anos e sensível à orientação do PCA (mesma ressalva metodológica das demais operações). Score alto puxado por 2025 (ano mais recente, peso 0,60).

## Conclusão
FinScore **767,5 → passa** no filtro eliminatório (Muito Abaixo do Risco / Berkley). Segue para o **módulo complementar** (Camadas 2/3/4). Pendências para a decisão final: FAP/DataPrev, situação fiscal (e-CAC/PGFN) e jurídico; e, no grupo, os 2 CNPJs pendentes (JNS Seguradora, JNA Agropecuária).

## Próxima ação
1. Coletar Módulo 2 (FAP, e-CAC, jurídico) para o complementar.
2. Confirmar composição do "Outras Despesas Administrativas" de 2025 (salto relevante).
