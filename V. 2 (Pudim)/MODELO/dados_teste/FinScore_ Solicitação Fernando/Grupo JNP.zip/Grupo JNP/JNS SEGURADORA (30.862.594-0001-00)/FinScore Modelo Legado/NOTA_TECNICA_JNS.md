# NOTA TÉCNICA — FinScore JNS SEGURADORA S.A. (Simulação Falsa 01 — teste, mapeamento SUSEP)

**Data:** 24/07/2026 · **Empresa:** JNS Seguradora S.A. — CNPJ 30.862.594/0001-00 (Grupo JNP) · **Período:** 2023–2025
**Natureza:** SIMULAÇÃO DE TESTE (não oficial). Motor de produção (`utils_finscore.executar_finscore`, sklearn 1.4.2), mas com **premissas de mapeamento SUSEP→16 campos definidas nesta nota e ainda não validadas** (Elpídio; se necessário, Dr. Fernando).

## Resultado
| Métrica | Valor |
|---|---|
| FinScore Bruto | **0,35** |
| FinScore Ajustado | **587,5** |
| Régua Berkley (decisória do projeto) | **500 < 587,5 ≤ 750 → Levemente Abaixo do Risco → LMI R$ 1.500.000, taxa 2,5% — PASSA o filtro eliminatório** |
| Régua interna do código | "Neutro" |

⚠️ **Divergência de réguas (conhecida):** o código classifica "Neutro"; a régua Berkley do projeto classifica **Levemente Abaixo do Risco**. Precedentes (JNH 767,5; FORNAX 227,5) usaram a régua Berkley como decisória. **Validação humana requerida.**

## Fonte
`JNS_DEMONSTRACOES_2023/2024/2025.pdf` (BP+DRE, demonstrações contábeis, Curitiba 30/06/2026) — intake `JNH/01_Modulo 1 - FinScore (Fontes)/JNS SEGURADORA (30.862.594-0001-00)/Balanco-DRE/`. **Equação patrimonial fecha nos 3 anos** (Ativo = Passivo + PL: 157.352.881,94 · 184.727.152,00 · 296.595.217,23). Sem recibo SPED (ressalva).

## Mapeamento SUSEP → 16 campos (PREMISSAS A VALIDAR)
| Campo | Conta SUSEP usada | 2023 | 2024 | 2025 | Ótica/impacto |
|---|---|---|---|---|---|
| p_Ativo_Circulante | Circulante | 81.160.393,74 | 132.578.548,98 | 149.432.996,72 | Liquidez/CCL |
| p_Ativo_Total | Total do Ativo | 157.352.881,94 | 184.727.152,00 | 296.595.217,23 | ROA/Giro |
| p_Caixa | Disponível (caixa e bancos) | 558.866,08 | 233.127,73 | 469.794,04 | **Aplicações (RF/fundos) NÃO incluídas** — mesmo debate da Callamarys (composição do caixa). Se incluídas (CP), caixa 2025 iria a ~28,2 mi |
| p_Estoques | — (seguradora) | 0 | 0 | 0 | Liquidez Seca removida do PCA pelo próprio motor |
| p_Contas_a_Pagar | Contas a pagar (grupo, PC) | 4.200.154,11 | 1.600.547,00 | 2.419.726,26 | PMP. **Débitos de operações com seguros/resseguros NÃO incluídos** |
| p_Contas_a_Receber | Créditos das op. com seguros e resseguros (PC) | 16.824.615,11 | 21.797.388,40 | 42.565.740,69 | PMR (prêmios a receber + operações) |
| p_Passivo_Circulante | Circulante | 78.868.287,72 | 98.896.591,24 | 155.838.941,57 | Inclui provisões técnicas CP (52,2 → 74,5 → 106,6 mi) |
| p_Passivo_Total | = Ativo Total (convenção Assertif) | idem AT | idem AT | idem AT | Endividamento |
| p_Patrimonio_Liquido | Patrimônio Líquido | 35.828.168,47 | 40.922.589,95 | 44.332.193,45 | 2025 inclui aumento de capital em aprovação (3,47 mi) |
| r_Receita_Total | **Prêmios ganhos** | 50.479.047,63 | 64.070.331,59 | 62.153.357,17 | Receita reconhecida (não prêmios emitidos: 72,2 · 71,3 · 111,2 mi) |
| r_Custos | **Sinistros ocorridos** | 7.995.842,33 | 43.592.461,14 | 43.268.372,12 | Custo direto. **Custos de aquisição (12,2 · 16,3 · 15,5 mi) e resultado com resseguro NÃO incluídos** |
| r_Despesa_de_Impostos | IR + CSLL | 868.030,02 | **−492.155,19** | 639.140,14 | 2024 = crédito (IR/CS positivos na DRE) → lançado negativo, precedente JNH 2023. "Despesas com Tributos" (2,2–2,7 mi) NÃO incluídas, alinhado ao padrão JNH |
| r_Despesa_de_Juros | — | 0 | 0 | 0 | DRE só traz Resultado Financeiro líquido POSITIVO (7,7 · 8,1 · 12,1 mi); sem abertura de juros → Cobertura de Juros = NaN → 0 no scaler |
| r_Depreciacao / r_Amortizacao | — | 0 | 0 | 0 | Não destacadas na DRE (dentro de Despesas Administrativas). **Limitação formal** — EBITDA subestimado |
| r_Lucro_Liquido | Lucro líquido do exercício | 3.399.952,80 | 2.813.985,06 | 3.390.160,35 | Margem 6,7% · 4,4% · 5,5% |

## Leitura dos índices (motor)
- Liquidez Corrente: 1,03 → 1,34 → 0,96 (2025 < 1 — provisões técnicas CP dobraram; ver casamento com ativos de resseguro 64,4 mi no CP).
- Endividamento: 0,77 → 0,78 → 0,85 (estrutura típica de seguradora: provisões técnicas dominam o passivo).
- Sinistralidade (sinistros/prêmios ganhos): 15,8% → 68,0% → 69,6% — salto forte em 2024; ver contrapartida no resultado com resseguro (−17,8 → +5,6 → +8,1 mi).
- PMP 2023 = 191,7 vs ~13–20 em 2024/25 — artefato do mapeamento (custos 2023 5x menores); não ler como prazo real.
- PCA: PC1 58,7%, PC2 41,3% (3 observações — fragilidade n=3 conhecida, caso FORNAX).

## Limitações e condicionantes
1. Mapeamento SUSEP→16 campos é **premissa desta análise** (não validada). Segurador não é o caso-base do modelo (concebido p/ plano de contas empresarial).
2. Depreciação/amortização = 0 (indisponíveis) → EBITDA/margem EBITDA distorcidos p/ baixo.
3. Resseguro (material: receita 33–35 mi em 2024/25) não modelado nos 16 campos.
4. Regulação SUSEP (capital mínimo, provisões) não capturada pelo modelo.
5. Sem recibo SPED; demonstrações de 2 pgs sem notas explicativas.
6. Sem balancetes mensais 2026 no intake.

## Conclusão (condicionada)
Com os documentos disponíveis, é possível concluir que a JNS obtém **FinScore 587,5**, que pela régua Berkley **passa o filtro eliminatório (Levemente Abaixo do Risco; LMI R$ 1,5 mi; taxa 2,5%)**. Porém, a conclusão fica **condicionada** à validação (i) do mapeamento SUSEP→16 campos desta nota, (ii) da divergência de réguas (código "Neutro" × Berkley), e (iii) da aceitação de seguradora como tomadora na operação (vs. ressalva societária SUSEP já registrada — distribuição de dividendos/atos societários de seguradora dependem de regras próprias).

**Próxima ação recomendada:** validar as premissas do mapeamento SUSEP→16 campos; se validadas, promover a simulação a oficial. A JNS integra esta devolução do template V2 como um dos casos de teste.
