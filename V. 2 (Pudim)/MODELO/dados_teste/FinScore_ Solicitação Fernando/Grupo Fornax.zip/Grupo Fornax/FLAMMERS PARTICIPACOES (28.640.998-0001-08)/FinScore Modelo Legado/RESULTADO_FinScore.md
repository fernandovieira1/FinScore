# FinScore FLAMMERS — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Bruto | **-0.1** (Neutro) |
| FinScore Ajustado | **475.0** (Neutro) |
| Régua Berkley | Neutro — recusar, salvo aprovação prévia Berkley (taxa 3%) |
| Variância explicada PCA | 57.5%, 42.5%, 0.0% |
|   Margem Líquida |   ROA |   ROE |      EBITDA |   Margem EBITDA |   Alavancagem |   Endividamento |   Imobilizado/Ativo |   Cobertura de Juros |   Giro do Ativo |   Período Médio de Recebimento |   Período Médio de Pagamento |   Liquidez Corrente |   CCL/Ativo Total |
|-----------------:|------:|------:|------------:|----------------:|--------------:|----------------:|--------------------:|---------------------:|----------------:|-------------------------------:|-----------------------------:|--------------------:|------------------:|
|              nan |  0.38 |  0.38 | 1.80104e+06 |             nan |         -0.02 |            0.01 |                0.68 |                nan   |               0 |                            nan |                          nan |               50.26 |              0.32 |
|              nan |  1.55 |  1.57 | 4.64439e+06 |             nan |         -0.01 |            0.01 |                0.98 |                nan   |               0 |                            nan |                          nan |                2.03 |              0.01 |
|              nan | 19.64 | 23.95 | 2.63104e+06 |             nan |         -0.01 |            0.18 |                0.56 |              62170.1 |               0 |                            nan |                          nan |                2.47 |              0.26 |
| PC   | Indice 1           |   Peso 1 | Indice 2        |   Peso 2 | Indice 3          |   Peso 3 |
|:-----|:-------------------|---------:|:----------------|---------:|:------------------|---------:|
| PC1  | Cobertura de Juros |    0.439 | Endividamento   |    0.439 | ROE               |    0.437 |
| PC2  | EBITDA             |    0.489 | CCL/Ativo Total |    0.471 | Liquidez Corrente |    0.459 |
| PC3  | Margem Líquida     |    0.812 | ROA             |    0.345 | Imobilizado/Ativo |    0.266 |

Fonte: balancetes anuais 2023–2025 (DF assinada de 2024 solicitada à contabilidade). Simulação de teste com o modelo atual; Serasa não informado (0).
