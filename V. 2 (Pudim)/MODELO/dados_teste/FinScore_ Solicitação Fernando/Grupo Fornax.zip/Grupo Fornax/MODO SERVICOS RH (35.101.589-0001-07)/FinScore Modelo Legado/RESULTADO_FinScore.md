# FinScore MODO — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Bruto | **1.16** (Levemente Abaixo do Risco) |
| FinScore Ajustado | **790.0** (Levemente Abaixo do Risco) |
| Régua Berkley | Muito Abaixo do Risco — LMI 1,5M; taxa 2% (aprova) |
| Variância explicada PCA | 69.9%, 30.1%, 0.0% |
|   Margem Líquida |      ROA |   ROE |   EBITDA |   Margem EBITDA |   Alavancagem |   Endividamento |   Imobilizado/Ativo |   Cobertura de Juros |   Giro do Ativo |   Período Médio de Recebimento |   Período Médio de Pagamento |   Liquidez Corrente |   CCL/Ativo Total |
|-----------------:|---------:|------:|---------:|----------------:|--------------:|----------------:|--------------------:|---------------------:|----------------:|-------------------------------:|-----------------------------:|--------------------:|------------------:|
|             0.66 | 29929.5  | -1.93 | 472034   |            0.66 |          0.52 |        15526.7  |                   0 |              1369.21 |        45490.4  |                              0 |                          nan |                0    |         -15525.7  |
|             0.88 |     0.89 | -0.16 | 124193   |            0.88 |          6.46 |            6.61 |                   0 |             18077.6  |            1.01 |                              0 |                          nan |                0.15 |             -5.61 |
|            22.71 |   359.15 | -0.09 |  82723.1 |           22.94 |         10.43 |         3784.37 |                   0 |                98.42 |           15.82 |                              0 |                          nan |                0    |          -3783.37 |
| PC   | Indice 1           |   Peso 1 | Indice 2          |   Peso 2 | Indice 3      |   Peso 3 |
|:-----|:-------------------|---------:|:------------------|---------:|:--------------|---------:|
| PC1  | ROE                |    0.361 | Giro do Ativo     |    0.361 | ROA           |    0.361 |
| PC2  | Cobertura de Juros |    0.496 | Liquidez Corrente |    0.48  | Margem EBITDA |    0.469 |
| PC3  | ROA                |    0.844 | Margem Líquida    |    0.34  | Endividamento |    0.25  |

Fonte: balancetes anuais 2023–2025 (DFs assinadas solicitadas à contabilidade). Simulação de teste com o modelo atual; Serasa não informado (0).
