# FinScore MOOVEN — Simulação de teste — 27/07/2026

| Métrica | Valor |
|---|---|
| FinScore Bruto | **1.61** (Muito Abaixo do Risco) |
| FinScore Ajustado | **902.5** (Muito Abaixo do Risco) |
| Régua Berkley | Muito Abaixo do Risco — LMI 1,5M; taxa 2% (aprova) |
| Variância explicada PCA | 84.2%, 15.8%, 0.0% |
|   Margem Líquida |   ROA |   ROE |      EBITDA |   Margem EBITDA |   Alavancagem |   Endividamento |   Imobilizado/Ativo |   Cobertura de Juros |   Giro do Ativo |   Período Médio de Recebimento |   Período Médio de Pagamento |   Liquidez Corrente |   CCL/Ativo Total |
|-----------------:|------:|------:|------------:|----------------:|--------------:|----------------:|--------------------:|---------------------:|----------------:|-------------------------------:|-----------------------------:|--------------------:|------------------:|
|             0.05 |  0.08 |  0.63 | 1.56966e+06 |            0.14 |          2.01 |            0.88 |                0.37 |                 1.55 |            1.69 |                          16.92 |                         0    |                0.72 |             -0.25 |
|             0.26 |  0.55 |  0.64 | 4.76832e+06 |            0.29 |         -0.6  |            0.15 |                0.07 |               191.4  |            2.09 |                          44.86 |                         4.88 |                6.36 |              0.78 |
|             0.21 |  0.65 |  0.96 | 6.35097e+06 |            0.23 |         -0.29 |            0.32 |                0.08 |               426.06 |            3.04 |                          33.62 |                         3.46 |                4.83 |              0.73 |
| PC   | Indice 1          |   Peso 1 | Indice 2        |   Peso 2 | Indice 3                   |   Peso 3 |
|:-----|:------------------|---------:|:----------------|---------:|:---------------------------|---------:|
| PC1  | Imobilizado/Ativo |    0.291 | CCL/Ativo Total |    0.291 | Alavancagem                |    0.29  |
| PC2  | ROE               |    0.573 | Giro do Ativo   |    0.46  | Cobertura de Juros         |    0.371 |
| PC3  | ROA               |    0.478 | Margem Líquida  |    0.458 | Período Médio de Pagamento |    0.402 |

Fonte: balancetes anuais 2023–2025 (DFs assinadas 2023/2024 solicitadas à contabilidade). Simulação de teste com o modelo atual; Serasa não informado (0).
