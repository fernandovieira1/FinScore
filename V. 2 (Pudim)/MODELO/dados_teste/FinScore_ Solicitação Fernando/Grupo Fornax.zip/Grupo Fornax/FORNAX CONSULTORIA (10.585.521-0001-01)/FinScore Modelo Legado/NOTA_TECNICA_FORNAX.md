# Nota Técnica — FinScore FORNAX (Simulação True / oficial)

**Empresa:** FORNAX CONSULTORIA EM INFORMATICA LTDA — CNPJ 10.585.521/0001-01
**Período:** 2023 / 2024 / 2025 (3 anos fechados)
**Fonte:** Balanço + DRE assinados (JCG Auditoria). Os 3 anos fecham: Ativo = Passivo Exigível + PL, diferença R$ 0,00.

## Resultado
- **FinScore Ajustado = 227,5 — Levemente Acima do Risco** (produção, scikit-learn 1.4.2; Bruto −1,09).
- **Confirmado pelo parecer do sistema:** 227,50 / decisão NÃO APROVAR.

## Convenção aplicada
- `p_Passivo_Total = Ativo Total` (convenção vigente do código: Dívida Bruta = Passivo_Total − PL).
- Contas de despesa/resultado em módulo (positivo).

## Leitura crítica (o número contradiz os fundamentos)
A FORNAX é uma consultoria muito lucrativa e crescendo: receita 35,0 → 43,3 → 48,7 mi; margem líquida 28% → 33% → 24%; margem EBITDA 40% → 44% → 38%. O "Levemente Acima do Risco / não aprovar" **não vem de fragilidade de caixa ou de resultado** — vem do **ano atípico de 2023**:

- Em 2023 a empresa distribuiu quase todo o lucro, deixando o **PL em R$ 113.153**. Isso gera **ROE 86,3 e Endividamento 0,98** (outliers). Como o modelo é relativo (z-score sobre 3 anos) e roda PCA sobre n=3, **esse ano domina o eixo** (z de ROE/Endividamento/Giro em 2023 = +1,41, o máximo com 3 pontos).
- **Sensibilidade:** removendo 2023 (só 2024+2025), o score vai de **227,5 para 142,5** — muda 85 pontos por um único ano atípico. O resultado é **frágil em relação a 2023**.
- **Custos:** `r_Custos = 0` (consultoria sem CMV) afeta **só o PMP** (fica N/A). **Não infla margens nem derruba o score** — as despesas de pessoal já estão subtraídas no Lucro Líquido e no EBIT/EBITDA. Não é o custo que pesa.

## Premissas / pontos a validar (ver OS ao Dr. Fernando)
1. Tratamento de custos em empresa de serviço sem CMV.
2. Efeito do PL atipicamente baixo em 2023 (distribuição de lucro) sobre o score.

## Campos imateriais
- D&A: depreciação 2024 = 457,53 (DRE); 2023/2025 não isoladas (imobilizado líquido ~0); amortização = 0.
- r_Despesa_de_Juros = total das Despesas Financeiras (2023 sem breakdown; total para consistência).
- p_Contas_a_Pagar (fornecedores): só há conta "Fornecedores" em 2025 (618,75); 2023/2024 = 0.

## Pendências
- Balancete do ano vigente (2026) para a análise complementar (solicitado à contabilidade).
- Validação das premissas 1 e 2 com o Dr. Fernando antes de tratar o "não aprovar" como definitivo.
